function chamarAPI() {
    fetch('https://randomuser.me/api/')
        .then(response => response.json())
        .then(data => {
            const user = data.results[0];
            const dados = `
                <p>Nome: ${user.name.first} ${user.name.last}</p>
                <p>Endereço: ${user.location.city}</p>
                <p>Usuário: ${user.login.username}</p>
                <img src="${user.picture.large}" alt="Foto do usuário">
            `;
 // O id 'dados' é uma div vazia no HTML
            document.getElementById('dados').innerHTML = dados;
        })
        .catch(error => console.error('Erro ao encontrar usuário:', error));
}